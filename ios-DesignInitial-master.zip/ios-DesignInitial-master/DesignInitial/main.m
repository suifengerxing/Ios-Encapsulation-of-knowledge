//
//  main.m
//  DesignInitial
//
//  Created by 王晓峰 on 2017/2/22.
//  Copyright © 2017年 wangxiaofeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        Student *stu1 = [Student shareManager];
        NSLog(@"shareManager -- %@",stu1.name);
        
        Student *stu2 = [[Student alloc] init];
        NSLog(@"init -- %@",stu2.name);
        
        Student *stu3 = [[Student alloc] initWithName:@"小明"];
        NSLog(@"init:Name --- %@",stu3.name);
    }
    return 0;
}
