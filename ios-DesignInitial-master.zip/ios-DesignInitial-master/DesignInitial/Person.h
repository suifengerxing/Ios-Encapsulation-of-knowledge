//
//  Person.h
//  DesignInitial
//
//  Created by 王晓峰 on 2017/2/22.
//  Copyright © 2017年 wangxiaofeng. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface Person : NSObject

/*
 子类调用 -init()方法时，会调用父类的 -init()方法；
 NS_UNAVAILABLE：子类不调用父类的初始函数，只调用子类自身的方法；
 如果没有写这段代码，则会报警告：
    Method override for the designated initializer of the superclass '-init' not found
 方法一：-(instancetype)init NS_UNAVAILABLE;
 方法二：在.m文件里增加下面代码
     -(instancetype)init
     {
         return  [self initWithName:@""];
     }
 */
-(instancetype)init NS_UNAVAILABLE;

-(instancetype)initWithName:(NSString *)name NS_DESIGNATED_INITIALIZER;

NS_ASSUME_NONNULL_END
@end
