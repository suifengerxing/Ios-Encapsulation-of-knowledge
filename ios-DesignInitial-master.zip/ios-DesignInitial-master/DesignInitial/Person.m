//
//  Person.m
//  DesignInitial
//
//  Created by 王晓峰 on 2017/2/22.
//  Copyright © 2017年 wangxiaofeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(instancetype)initWithName:(NSString *)name
{
    self = [super init];
    if (self) {
    }
    return self;
}

//方法一：
//-(instancetype)init
//{
//    return  [self initWithName:@""];
//}
//方法二:
//在.h文件里面添加 -(instancetype)init NS_UNAVAILABLE;

@end
