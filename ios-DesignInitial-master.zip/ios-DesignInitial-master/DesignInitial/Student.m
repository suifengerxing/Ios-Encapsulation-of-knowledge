//
//  Student.m
//  DesignInitial
//
//  Created by 王晓峰 on 2017/2/22.
//  Copyright © 2017年 wangxiaofeng. All rights reserved.
//

#import "Student.h"

@implementation Student
+(instancetype)shareManager
{
    return  [[[self class] alloc] initWithName:@""];
}

-(instancetype)init
{
    return  [self initWithName:@""];
}
-(instancetype)initWithName:(NSString *)name
{
    if (self = [super initWithName:name]) {
        self.name = name;
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [self initWithName:@""];
    if (!self) {
        return  nil;
    }
    return self;
}
@end
