//
//  Student.h
//  DesignInitial
//
//  Created by 王晓峰 on 2017/2/22.
//  Copyright © 2017年 wangxiaofeng. All rights reserved.
//

#import "Person.h"

@interface Student : Person
NS_ASSUME_NONNULL_BEGIN
@property(nonatomic,strong,nullable) NSString *name;

-(instancetype)init;
+(instancetype)shareManager;
-(instancetype)initWithName:(NSString *)name NS_DESIGNATED_INITIALIZER;
NS_ASSUME_NONNULL_END
@end
